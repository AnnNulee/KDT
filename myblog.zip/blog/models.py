from django.db import models


#게시글을 저장할 모델(db)
class Post(models.Model):
    pass


#게시글의 종류를 지정.
class Category(models.Model):
    pass


#게시글의 해시태그
class Tag(models.Model):
    pass

 
# 댓글
class Comment(models.Model):
    pass